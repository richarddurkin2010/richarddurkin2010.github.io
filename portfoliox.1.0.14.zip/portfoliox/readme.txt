=== PortfolioX ===

Contributors: nalam
Tags: two-columns, blog, portfolio, education, right-sidebar, custom-background, custom-colors, custom-menu, custom-logo, editor-style, featured-images, full-width-template, sticky-post, theme-options, threaded-comments, translation-ready
Requires PHP: 5.6
Requires at least: 5.0
Tested up to: 6.9
Stable tag: 1.0.14
License: GNU General Public License v2 or later
License URI: http://opensource.org/licenses/gpl-2.0.php

== Description ==
PortfolioX is a premium portfolio WordPress theme with a clean and minimalistic design. It features a responsive layout, post formats and lots of flexible options that make it easy to customize to your needs. It's perfect for freelancers, designers, developers, photographers artists and all other professionals. Portfolio X is also a creative WordPress theme. It is not only a unique portfolio theme, but also a multi-purpose theme that can be used for a wide range of websites such as portfolio, personal blog, business, photography, online store, etc.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Copyright ==

PortfolioX WordPress Theme, Copyright 2021 Noor alam
PortfolioX is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

PortfolioX theme used the following third-party resources:


* Bootstrap, Copyright 2011–2021 Twitter
License: MIT
Source: https://getbootstrap.com/

* Font Awesome icons, Copyright Dave Gandy
Icons License: CC BY 4.0 
Fonts License: SIL OFL 1.1 
Source: http://fontawesome.io/

* SlickNav, Copyright 2016 Josh Cope
License: MIT 
Source: https://github.com/ComputerWolf/SlickNav


== Screenshot ==

Image for theme screenshot, self created
License: CC0 1.0 Universal (CC0 1.0)


* Screenshot Header image
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/815849


== Changelog ==

= 1.0.12 =
* Google Fonts updated
* Tested Wordpress latest version 6.9 

= 1.0.12 =
* Added customizer options for read more button (text, color, and style)

= 1.0.10 =
* New style added in readmore button 
* New style added for heading

= 1.0.9 =
* Posts published & update date issue fixed

= 1.0.6 =
* mobile and table view issue fixed

= 1.0.5 =
* Fixed new style in sticky posts

= 1.0.4 =
* Added new options and info

= 1.0.3 =
* Profile image issue fixed in customizer

= 1.0.2 =
* Added new style for header
* Added new style for menu

= 1.0.0 =
* Initial release

== Credits ==

* Based on Underscores https://underscores.me/, (C) 2012-2017 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)





